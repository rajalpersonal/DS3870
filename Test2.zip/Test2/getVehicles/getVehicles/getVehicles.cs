using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace getVehicles
{
    public static class getVehicles
    {
        private class VehicleClass
        {
            public string VIN { get; set; }
            public string Make { get; set; }
            public string Model { get; set; }
            public int Year { get; set; }
            public double MPL { get; set; }
            public VehicleClass(string strVIN, string strMake, string strModel, int intYear, double dblMPG)
            {
                VIN = strVIN;
                Make = strMake;
                Model = strModel;
                Year = intYear;
                MPL = (dblMPG / 3.78541);
            }
        }
        [FunctionName("getVehicles")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            string strMinMilesPerLiter = req.Query["MinMilesPerLiter"]; //Having issue here
            log.LogInformation("HTTP trigger on getVehicles processed a request for: " + strMinMilesPerLiter);

            VehicleClass Ford = new VehicleClass("VIN-78re540jk93j", "Ford", "Maverick", 2022, 31);
            VehicleClass Toyota = new VehicleClass("VIN-VH5820req", "Toyota", "Prius", 2010, 42);
            VehicleClass Mercedes = new VehicleClass("VIN - MIL839", "Mercedes", "UniMog", 1990, 2.6);

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);

            List<VehicleClass> arrVehicleClass = new List<VehicleClass>();
            arrVehicleClass.Add(Ford);
            arrVehicleClass.Add(Toyota);
            arrVehicleClass.Add(Mercedes);

            List<VehicleClass> lstFoundVehicles = new List<VehicleClass>();
            foreach(VehicleClass vCurrent in arrVehicleClass)
            {
                if(strMinMilesPerLiter == vCurrent) //Having issue here
                {
                    lstFoundVehicles.Add(vCurrent);
                }
            }
            if(lstFoundVehicles.Count > 0)
            {
                return new OkObjectResult(lstFoundVehicles);
            }
            else
            {
                return new OkObjectResult("Vehicle Not Found");
            }
        }
    }
}
