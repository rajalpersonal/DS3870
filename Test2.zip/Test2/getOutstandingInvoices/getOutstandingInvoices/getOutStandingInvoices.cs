using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Data;

namespace getOutstandingInvoices
{
    public static class getOutStandingInvoices
    {
        [FunctionName("getEmployees")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("HTTP trigger on getEmployees.");

            string strCustomerName = req.Query["strCustomerName"];
            string strMinInvoiceValue = req.Query["strMinInvoiceValue"];
            log.LogInformation("Queried for: " + strCustomerName + " " + strMinInvoiceValue);

            DataSet dsCustomer = new DataSet();
            string strConnection = "Server = tcp:myserver.database.windows.net,1433; Database = myDataBase; UserID = mylogin@myserver; Password = myPassword; Trusted_Connection = False; Encrypt = True";
            string strQuery = "SELECT InvoiceNumber, Amount, Paid FROM tblInvoices AS I JOIN tblCustomers as C ON I.CustomerID = C.CustomerID WHERE Name = @parCustomerName AND Amount = @parMinInvoiceValue";
            try
            {
                using (SqlConnection conCustomer = new SqlConnection(strConnection));
                using (SqlCommand comCustomer = new SqlCommand(strQuery, conCustomer));
                {
                    SqlParameter parCustomerName = new SqlParameter("parCustomerName", SqlDbType.VarChar);
                    parCustomerName.Value = strCustomerName;
                    comCustomer.Parameters.Add(parCustomerName);

                    SqlParameter parMinInvoiceValue = new SqlParameter("parMinInvoiceValue", SqlDbType.Decimal);
                    parMinInvoiceValue = strMinInvoiceValue;
                    comCustomer.Parameters.Add(parMinInvoiceValue);

                    SqlDataAdapter daCustomer = new SqlDataAdapter(comCustomer);
                    daCustomer.Fill(dsCustomer);
                    return new OkObjectResult(JsonConvert.SerializeObject(dsCustomer.Tables[0]));
                }
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message.ToString());
            }
        }
    }
}
